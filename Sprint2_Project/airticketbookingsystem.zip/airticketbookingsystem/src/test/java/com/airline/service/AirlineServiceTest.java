package com.airline.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.airline.entity.Airline;
import com.airline.model.AirlineDTO;
import com.airline.repository.AirlineRepository;
import com.airline.util.AirlineConverter;

@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class AirlineServiceTest {

	@Autowired
	private AirlineService airlineService;
	
	@Autowired
	private AirlineConverter airlineConverter;
	
	@MockBean
	private AirlineRepository airlineRepository;
	
	@Test
	@Order(1)
	void saveAirlineTest()
	{
		Airline airline = Airline.builder().airlineName("air india").fare(3300.37f).build();
		
		Mockito.when(airlineRepository.save(airline)).thenReturn(airline);
		AirlineDTO dto = airlineConverter.convertToAirlineDTO(airline); 
		assertEquals(dto.getAirlineName(), airline.getAirlineName());
	}
	
	@Test
	@Order(3)
	void updateAirlineTest()
	{
		Airline airline = Airline.builder().airlineName("air india").fare(3300.37f).build();
		
		Optional<Airline> opair= Optional.of(airline);
		Mockito.when(airlineRepository.findById(airline.getId())).thenReturn(opair);
		Airline p=opair.get();
		airline.setAirlineName("indigo");;
		
		Mockito.when(airlineRepository.save(airline)).thenReturn(p);
		 
		 AirlineDTO dto=airlineService.updateAirline(airline.getId(), airline);
		assertEquals(dto.getAirlineName(), p.getAirlineName());
	}
	
	@Test
	@Order(2)
	@DisplayName("Negative Test Case")
	void deleteAirlineByIdTest()
	{
		Airline air = Airline.builder().airlineName("air india").fare(3300.37f).build();
		
		Optional<Airline> opair= Optional.of(air);
		Mockito.when(airlineRepository.findById(opair.get().getId())).thenReturn(opair);
		
		assertThat(airlineService.deleteAirlineById(opair.get().getId())).isNotEqualTo("record deleted successfully");
	}
}