package com.airline.model;

import java.util.Date;

import javax.validation.constraints.NotNull;

import com.airline.entity.Airline;
import com.airline.entity.Flight;
import com.airline.entity.Passenger;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class TicketBookingDTO {
	
	private int ticketId;
	@NotNull(message = "Number of passenger field can not be null")
	private int no_of_passenger;
	private double totalFare;
	@NotNull(message = "Date can not be null")
	private Date Date=new Date();
	@NotNull(message = "Source can not be null")
	private String source;
	@NotNull(message = "Destination can not be null")
	private String destination;

	private Flight flightId;
	
	private Airline airlineId;
	
	private Passenger passengerId;
}
