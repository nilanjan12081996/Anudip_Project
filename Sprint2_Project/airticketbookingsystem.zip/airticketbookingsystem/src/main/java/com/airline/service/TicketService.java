package com.airline.service;

import java.time.LocalDate;

import com.airline.entity.TicketBooking;
import com.airline.model.TicketBookingDTO;

public interface TicketService {
	String bookFlight(int fId,int pId,TicketBooking ticketbooking);
	String cancelBooking(int id);
	TicketBookingDTO getDistinctByTicketId(int id);
}
