package com.airline.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airline.entity.User;
import com.airline.repository.UserRepository;
import com.airline.service.UserService;
@Service
public class UserServiceImpl implements UserService{
	@Autowired
	UserRepository userRepository;
	//method used to login to the system using the userName and password
	@Override
	public User login(String userName, String password) {
		User user=userRepository.findByUserNameAndPassword(userName, password);
		return user;
	}

}
