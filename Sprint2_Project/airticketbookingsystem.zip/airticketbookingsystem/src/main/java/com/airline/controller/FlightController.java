package com.airline.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.airline.entity.Admin;
import com.airline.entity.Airline;
import com.airline.entity.Flight;
import com.airline.model.AdminDTO;
import com.airline.model.AirlineDTO;
import com.airline.model.FlightDTO;
import com.airline.model.PassengerDTO;
import com.airline.service.FlightService;
import com.airline.util.FlightConverter;


@RestController
@RequestMapping("/api")
public class FlightController {
	@Autowired
	private FlightService flightService;
	@Autowired
	FlightConverter flightConverter;
	//build save flight REST API
	@PostMapping("/saveFlight/{role}")
	public ResponseEntity<?> saveFlight(@PathVariable("role") String role, @RequestBody FlightDTO flightDTO)
	{
		final Flight fl = flightConverter.convertToFlightEntity(flightDTO);
		if(role.equals("admin"))
		{
		return new ResponseEntity<FlightDTO>(flightService.saveFlight(fl),
				HttpStatus.CREATED);
		}
		else {
			return new ResponseEntity<String>("You are not an admin",HttpStatus.BAD_REQUEST);
		}
	}
	//build assign flight to airline REST API
	@PostMapping("/assignFlight/{fid}/{aid}")
	public ResponseEntity<FlightDTO> assignFlightToAirline(@PathVariable ("fid") int flightId,@PathVariable("aid") int airlineId)
	{
		return new ResponseEntity<FlightDTO>(flightService.assignFlightToAirline(flightId, airlineId),HttpStatus.OK);
	}
	//build Search flight REST API
	@GetMapping("/searchFlight/{source}/{destination}")
	public List<FlightDTO> searchFlight(@PathVariable("source") String source,@PathVariable("destination") String destination)
	{
		return flightService.searchFlight(source,destination);
	}
	//build Update Airline By Id REST API
		@PutMapping("/updateFlight/{id}")
		public ResponseEntity<FlightDTO> updateFlight(@PathVariable("id") int id,@RequestBody FlightDTO flightDTO)
		{
	   final Flight flight=flightConverter.convertToFlightEntity(flightDTO);
	   return new ResponseEntity<FlightDTO>(flightService.updateFlight(id, flight),HttpStatus.OK);
	 }
		//build Get Flight REST API
		@GetMapping("/getFlightById/{id}")
		public FlightDTO getFlightById(@PathVariable int id)
		{
			return flightService.getFlightById(id);
		}
		//build DELETE Flight by ID REST API
		@DeleteMapping("/deleteFlightById/{id}")
		public String deleteFlightById(@PathVariable int id)
		{
			return flightService.deleteFlightById(id);
		}
}
